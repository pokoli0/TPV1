/*Clase Game: contiene, al menos, el tama�o de la ventana, punteros a la ventana y al renderer, a los
elementos del juego (usa el tipo vector), el booleano exit, y el array de texturas (ver m�s abajo). Define
tambi�n las constantes que sean necesarias. Implementa m�todos p�blicos para inicializarse y destruirse,
el m�todo run con el bucle principal del juego, m�todos para dibujar el estado actual del juego (m�todo
render), actualizar (m�todo update), manejar eventos (m�todo handleEvents), obtener la direcci�n de
movimiento de los alien�genas (m�todo getDirection), informar de que no es posible moverse otra iteraci�n
m�s en la direcci�n actual (m�todo cannotMove) y disparar l�seres (m�todo fireLaser).
*/
#pragma once
#include <SDL.h>
#include <vector>
#include "Alien.h"
#include "Bunker.h"
#include "Cannon.h"
#include "Laser.h"
#include "texture.h"
#include <string>
#include <array> 
#include <random>
#include "InfoBar.h"
using namespace std;


class Game
{
private:
	//constantes
	static const int NUM_TEXTURES = 5, WINDOW_WIDTH = 800, WINDOW_HEIGHT = 600;
	//const char* textRoot = "../images/"; //nos da error y no funciona. No es estrictamente necesaria asiq preferimos no usarla
	const string MAPAS [3] = {"../mapas/original.txt","../mapas/trinchera.txt","../mapas/lluvia.txt"};
	const int MAXIMUN_ALIEN_HEIGHT = 450; //altura m�xima a la q pueden llegar los aliens. al llegar a ella, pierdes
	const string FILE = "../mapas/save.txt";

	//cosas de SDL
	SDL_Window* window = nullptr;
	SDL_Renderer* renderer = nullptr;
	mt19937_64 randomGenerator;
	

	vector<Alien*> aliens;
	vector<Bunker*> bunkers;
	vector<Laser*> lasers;
	Cannon* cannon;
	InfoBar* infoBar;

	bool canMove = true;
	int alienDirection = 1;
	bool exit = false;
	int score = 0;

#pragma region cosas de textura
	struct TextureInfo {
		const char* name;
		int framesVerticales;
		int framesHorizontales;
	};
	enum textureName { STARS, SPACESHIP, BUNKER, ALIEN, NUMBERS};
	textureName textureIndex; //no, no hace falta. pero nos dice q lo usemos de todas maneras.

	TextureInfo textInfo[NUM_TEXTURES]{
		TextureInfo {"../images/stars.png", 1, 1},
		TextureInfo {"../images/spaceship.png", 1, 1},
		TextureInfo {"../images/bunker.png", 1, 4},
		TextureInfo {"../images/aliens.png", 3, 2},
		TextureInfo {"../images/numbers.png", 1, 10}
	};

	Texture* textureArray[NUM_TEXTURES]; //array est�tico
	TextureInfo textureInfoArray[NUM_TEXTURES];
#pragma endregion


public:
	Game(const int &entrada);
	~Game();
	void quit();
	void Run();
	void UpdateVidas();
	

	int getDirection() const;
	void cannotMove();
	int GetWindowWidth() const {return WINDOW_WIDTH;}
	void fireLaser(const point2D &pos, const int &center, const int &dir, const bool &fromAlien);
	int RandomGenerator(int min, int max);
	

private: //metodos privados
	void Render();
	void Update();
	void handleEvents();


	void readMap(const int& numMapa);
	void save();
	void load();

	void UpdateAliens();
	void UpdateBunkers();
	void UpdateLasers();
	void LowerAliens();
	void addScore(const int &scoreToAdd);
};

