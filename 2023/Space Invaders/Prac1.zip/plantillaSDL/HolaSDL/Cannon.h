/*Clase Cannon : al igual que los anteriores, sus atributos incluyen su posici�n actual, un puntero a su textura y
un puntero al juego(que utilizar� para lanzar l�seres).Adem�s, mantiene la direcci�n actual del movimiento,
el n�mero de vidas que le quedan y el tiempo restante de recarga del l�ser.Implementa tambi�n m�todos
para construirse, dibujarse(render), actualizarse, es decir, moverse(m�todo update), recibir da�o(m�todo
hit) y manejar eventos del teclado(m�todo handleEvent), que determinan el estado de movimiento y
permiten lanzar el l�ser(barra espaciadora).*/

#pragma once
#include "checkML.h"
#include "texture.h"
#include "vector2D.h"
#include <string>
using uint = unsigned int;
using namespace std;

class Game; //declaracion anticipada
class Cannon
{
private:
	point2D pos;
	Texture* text;
	int direccion = 0;
	int vidas = 3;
	const int TIEMPORECARGA = 700;
	uint lastTimeShoot = 0;
	Game* game;
	SDL_Rect rectCannon;

	const int VELOCIDAD = 30;

public:
	Cannon();
	Cannon(int posx, int posy, Texture* tx, Game* g, int v);

	void Render();
	bool Update();
	void Hit();
	void handleEvent(SDL_Event event);
	SDL_Rect* GetSDLRect();
	string getInfo() const;
	int getVidas() const { return vidas;}

private: //metodos privados
	void TryToShoot();
};

