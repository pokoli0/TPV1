#include "Laser.h"
#include "checkML.h"
using namespace std;

Laser::Laser() : pos(), velocidad(), vieneDeAlien() {}
Laser::Laser(int x, int y, int dir, bool alien, SDL_Renderer* r) : 
	pos(x, y), velocidad(0, 20*dir), vieneDeAlien(alien), renderer(r) {

	rectLaser.w = LASER_WIDTH;			//el tama�o no var�a, por lo que lo podemos definir en la constructora
	rectLaser.h = LASER_HEIGHT;

}

void Laser::Render() {
	//def: int SDL_SetRenderDrawColor(SDL_Renderer * renderer, Uint8 red, Uint8 green, Uint8 blue, Uint8 alpha);
	if (vieneDeAlien) {
		SDL_SetRenderDrawColor(renderer, 0, 0, 255, 50); //red
	}
	else
		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); //green 
	rectLaser.x = pos.getX();
	rectLaser.y = pos.getY();
	

	SDL_RenderFillRect(renderer, &rectLaser); //lo dibuja como un rect�ngulo
}

bool Laser::Update(const vector<Alien*> &aliens, const vector<Bunker*> &bunkers, const vector<Laser*> &lasers, Cannon* cannon) {
	//avanza de acuerdo a su velocidad
	pos = pos + velocidad;
	
	bool hasCollided;
	hasCollided = hasCollidedBunkers(bunkers);

	if (!hasCollided)
	{
		if (!vieneDeAlien)
			hasCollided = hasCollidedAliens(aliens);
		else
		{
			hasCollided = SDL_HasIntersection(&rectLaser, cannon->GetSDLRect());
			if (hasCollided)
				cannon->Hit();
			else
				hasCollided = hasCollidedLasers(lasers);

		}
			
	}
		

	return !hasCollided && !hasBeenHit && pos.getY() > 0; //para q no se salga
}

bool Laser::hasCollidedAliens(const vector<Alien*> aliens)
{
	int i = 0; bool hasCollided = false;
	while (!hasCollided && i < aliens.size())
	{
		if (hasCollided = SDL_HasIntersection(&rectLaser, aliens[i]->GetSDLRect()))
			aliens[i]->Hit();
		else
			i++;
	}
	return hasCollided; //devuelve true si ha colisionado
}

bool Laser::hasCollidedBunkers(const vector<Bunker*> bunkers)
{
	int i = 0; bool hasCollided = false;
	while (!hasCollided && i < bunkers.size())
	{
		if (hasCollided = SDL_HasIntersection(&rectLaser, bunkers[i]->getSDLRect()))
			bunkers[i]->Hit();
		else
			i++;
	}

	return hasCollided; //devuelve true si ha colisionado
}

bool Laser::hasCollidedLasers(const vector<Laser*> lasers)
{
	bool hasCollided = false;
	int i = 0;
	while (!hasCollided && i < lasers.size())
	{
		if (!lasers[i]->isFromAlien() && SDL_HasIntersection(&rectLaser, lasers[i]->getSDLRect()))
		{
			lasers[i]->Hit();
			hasCollided = true;
		}
			
		else
			i++;
	}

	return hasCollided; //devuelve true si ha colisionado
}

bool Laser::isFromAlien()
{
	return vieneDeAlien;
}

SDL_Rect* Laser::getSDLRect()
{
	return &rectLaser;
}

void Laser::Hit()
{
	hasBeenHit = true;
}

string Laser::getInfo()
{
	string info;
	int dir;
	if (vieneDeAlien) dir = 1;
	else dir = -1;
	info = "3 " + to_string(pos.getX()) + " " + to_string(dir) +
		" " + to_string(velocidad.getY()) + " " + to_string((int)vieneDeAlien);

	return info;
}
