#include "Bunker.h"
#include "checkML.h"
using namespace std;

Bunker::Bunker() : pos(), vidas(), text() {}
Bunker::Bunker(int x, int y, int v, Texture* t) :
	pos(x, y), vidas(v), text(t) {

	//como el bunker no se mueve, podemos definirlo en la constructora
	rectBunker.x = pos.getX();
	rectBunker.y = pos.getY();
	rectBunker.w = text->getFrameWidth();
	rectBunker.h = text->getFrameHeight();
}

void Bunker::Render() {
	

	//llama al render de texture.h
	text->renderFrame(rectBunker, 0, text->getNumColumns() - vidas);
}

void Bunker::Hit() {
	//Num de vidas disminuye y se modifica apariencia
	vidas--;
}

string Bunker::getInfo() const
{
	string info;
	info = "2 " + to_string(pos.getX()) + " " + to_string(pos.getY()) + " " + to_string(vidas);


	return info;
}

SDL_Rect* Bunker::getSDLRect() //devuelve puntero al rect de bunker
{
	return &rectBunker;
}

//returns false si ha perdido todas sus vidas
bool Bunker::Update() {
	return vidas > 0;
}

