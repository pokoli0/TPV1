
#include "checkML.h"
#include <iostream>
#include "Game.h"

int main(int argc, char* argv[])
{
	//preguntar q mapa quiere el jugador/ si quiere cargar partida
	int entrada;
	cout << "para cargar partida, escriba 9." << endl;
	cout << "para crear partida nueva, introduzca el numero de mapa que quiera: clasico (0), trinchera (1), lluvia (0)" << endl;
	cin >> entrada;
	while (entrada != 9 && !(entrada < 3 && entrada >= 0))
		cin >> entrada;
	

	try {
		Game* game = new Game(entrada);
		game->Run();
		delete game;
	}
	
	catch (const string Error) {
		cout << "exception: " << Error;
		SDL_Quit();
		
	}

	return 0;
}
