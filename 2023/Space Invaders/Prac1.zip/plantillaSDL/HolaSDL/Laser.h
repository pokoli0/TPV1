/*Clase Laser: contiene su posici�n (tipo Point2D), una velocidad (tipo Vector2D) y un booleano que indica
si procede de un alien�gena o de la nave que controla el jugador. Implementa m�todos para construirse,
dibujarse (render) y actualizarse (m�todo update). La actualizaci�n consiste en avanzar de acuerdo a
su velocidad y comprobar si ha acertado a alg�n objetivo. Los l�seres lanzados por el jugador hieren a
los alien�genas, mientras que los lanzados por los alien�genas da�an al jugador. Los l�seres hieren a los
b�nkeres independientemente de su origen. Cuando dos disparos de origen distinto se cruzan se anulan
mutuamente. Se pueden dibujar como un rect�ngulo de color con SDL_RenderFillRect.
*/
#pragma once
#include "Vector2D.h"
#include <vector>
#include "texture.h"
#include "checkML.h"
#include "Alien.h"
#include "Bunker.h"
#include "Cannon.h"
#include <string>
using namespace std;



class Laser
{
private:
	point2D pos;
	Vector2D<> velocidad;
	bool vieneDeAlien; //true si laser viene de alien, false si laser viene de jugador
	bool hasBeenHit = false;

	SDL_Rect rectLaser;
	SDL_Renderer* renderer;

	static const int LASER_WIDTH = 5, LASER_HEIGHT = 20; //para el rectangulo

public:
	Laser();
	Laser(int x, int y, int dir, bool alien, SDL_Renderer*);

	void Render();
	bool Update(const vector<Alien*> &aliens, const vector<Bunker*> &bunkers, const vector<Laser*> &lasers, Cannon* cannon);
	bool hasCollidedAliens(const vector<Alien*> aliens);
	bool hasCollidedBunkers(const vector<Bunker*> bunkers);
	bool hasCollidedLasers(const vector<Laser*> lasers);
	bool isFromAlien();
	SDL_Rect* getSDLRect();
	void Hit();
	string getInfo();
};

