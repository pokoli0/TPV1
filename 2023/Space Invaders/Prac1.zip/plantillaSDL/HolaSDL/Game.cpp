#include "checkML.h"
#include "Game.h"
#include <SDL_image.h>
#include <ctime>
#include <fstream>
//#include <filesystem>
//using uint = unsigned int;


//constructora. Carga las texturas, crea la ventana, el renderer y el randomGenerator, crea los objetos (en sus posiciones correctas)
Game::Game(const int &entrada) {

	//las cosas de SDL
	SDL_Init(SDL_INIT_EVERYTHING);
	window = SDL_CreateWindow("SPACE INVADERS", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	if (window == nullptr || renderer == nullptr)  //si no encuentra:
		throw string ("Error loading SDL window or renderer");

	
	mt19937_64 randomGenerator(time(nullptr)); //el random generator
	
	//cargar texturas
	try {
		for (int i = 0; i < NUM_TEXTURES; i++) {
			textureArray[i] = new Texture(renderer, textInfo[i].name,			//renderer, nombre
				textInfo[i].framesVerticales, textInfo[i].framesHorizontales);  //numero de frames
		}
	} catch (string e) { throw string("archivo de textura no encontrado o no v�lido"); }
	catch (exception e) { throw string("problema al cargar la textura"); }
	

	if (entrada != 9)
		readMap(entrada);
	else
		load();
}

//lee la informacion de un mapa (no una partida guardada)
void Game::readMap(const int& numMapa)
{
	//Para la lectura de mapa hemos asumido q solo hay un ca��n y los elementos est�n en orden.
	//tambien hemos considerado q las coordenadas son correctas.
	ifstream entradaMapa; entradaMapa.open(MAPAS[numMapa]);			//aqui es donde se decide q mapa jugar
	if (!entradaMapa.is_open())
		throw string("fichero de mapa no encontrado");


	int numObjeto, x, y, subt;
	entradaMapa >> numObjeto;

	textureIndex = SPACESHIP;
	if (numObjeto == 0)
	{
		entradaMapa >> x >> y;
		cannon = new Cannon(x, y, textureArray[textureIndex], this, 3);
		entradaMapa >> numObjeto;
	}

	textureIndex = ALIEN;
	while (numObjeto == 1)
	{
		entradaMapa >> x >> y >> subt;
		aliens.push_back(new Alien(x, y, subt, (x % 2 == 0), textureArray[textureIndex], this));
		entradaMapa >> numObjeto;
	}

	textureIndex = BUNKER;
	while (!entradaMapa.fail() && numObjeto == 2)
	{
		entradaMapa >> x >> y;
		bunkers.push_back(new Bunker(x, y, 4, textureArray[textureIndex]));
		entradaMapa >> numObjeto;
	}

	infoBar = new InfoBar(textureArray[4], textureArray[1], score, cannon->getVidas());
}

void Game::Render() {
	try {
		SDL_RenderClear(renderer);

		//fondo
		textureIndex = STARS;
		textureArray[textureIndex]->render();

		// los objetos
		for (int i = 0; i < bunkers.size(); i++)
		{
			bunkers[i]->Render();
		}
		for (int i = 0; i < aliens.size(); i++)
		{
			aliens[i]->Render();
		}
		for (int i = 0; i < lasers.size(); i++)
		{
			lasers[i]->Render();
		}
		cannon->Render();
		infoBar->Render();

		//mostrarlo
		SDL_RenderPresent(renderer);
	}
	catch (exception e) { throw string("ha ocurrido un problema con el render. Probablemente culpa de SDL."); }
}

void Game::Run() { 
	while (!exit)
	{
		Render();
		Update();
		handleEvents();

		SDL_Delay(50);
	}
}

void Game::UpdateVidas()
{
	infoBar->UpdateVidas();
}

void Game::Update() {

	UpdateLasers();
	UpdateBunkers();
	UpdateAliens();

	if (!canMove)								//si se ha llamado al cannotmove()
	{	
		alienDirection = alienDirection * (-1); //se invierte su direccion
		LowerAliens();							//se bajan (y se incrementa su velocidad)
		canMove = true;
	}

	if (!cannon->Update() || aliens.empty()) //si pierdes el ca��n, mueres
		quit();
}

//bucle que llama a todos los updates de alien
void Game::UpdateAliens()
{
	int i = 0;
	while (i < aliens.size())
	{
		if (!aliens[i]->Update())
		{
			addScore(aliens[i]->GetScore());
			delete aliens[i]; 
			aliens.erase(aliens.begin() + i);
		}
		else
			i++;
	}
}

void Game::UpdateBunkers()
{
	int i = 0;
	while (i < bunkers.size())
	{
		if (!bunkers[i]->Update())
		{
			delete bunkers[i]; 
			bunkers.erase(bunkers.begin() + i);
		}
		else i++;
	}
}

void Game::UpdateLasers()
{
	int i = 0;
	while (i < lasers.size())
	{
		if (!lasers[i]->Update(aliens, bunkers, lasers, cannon))
		{
			delete lasers[i]; 
			lasers.erase(lasers.begin() + i);
		}
		else i++;
	}
}

//baja los aliens e incrementa su velocidad.
void Game::LowerAliens() 
{
	bool hasLost = false; int i = 0;
	while (!hasLost && i < aliens.size())
	{
		hasLost = aliens[i]->Lower(MAXIMUN_ALIEN_HEIGHT);
		i++;
	}

	if (hasLost)
		quit();
}

//si el evento es alguno de los que nos interesan, se lo pasa a cannon o lo ejecuta
void Game::handleEvents()
{
	SDL_Event event;
	while (SDL_PollEvent(&event) && !exit) {
		
		//si se ha pulsado una tecla
		if (event.type == SDL_KEYDOWN) {
			if (event.key.keysym.sym == SDLK_ESCAPE) quit();//si es esc se cierra
			else if (event.key.keysym.sym == SDLK_RIGHT || event.key.keysym.sym == SDLK_LEFT //si son las flechas
				|| event.key.keysym.sym == SDLK_SPACE) //o el espacio, se lo pasas a cannon
				cannon->handleEvent(event);
			else if (event.key.keysym.sym == SDLK_s)
				save();
		}

		//si se suelta una tecla
		else if (event.type = SDL_KEYUP)
		{
			if (event.key.keysym.sym == SDLK_RIGHT || event.key.keysym.sym == SDLK_LEFT) //si son las flechas te dejas de mover
				cannon->handleEvent(event);
		}
	}
}



int Game::getDirection() const{
	return alienDirection;
}

//suma scoretoadd a la score y se la pasa a infobar para q la actualice
void Game::addScore(const int &scoreToAdd)
{
	score += scoreToAdd; 
	infoBar->UpdateScore(score);

}

void Game::cannotMove() {
	canMove = false;
}

void Game::fireLaser(const point2D &pos, const int &center, const int &dir, const bool &fromAlien) {
	lasers.push_back(new Laser(pos.getX()+center, pos.getY(), dir, fromAlien, renderer));
}

//genera un entero aleatorio entre min y max
int Game::RandomGenerator(int min, int max)
{
	return uniform_int_distribution<int>(min, max)(randomGenerator);
}

//cambia exit a false para que se acabe el bucle de juego
void Game::quit() {

	exit = true;
}

//destructora
Game::~Game()
{
	for (int i = 0; i < aliens.size(); i++)
		delete aliens[i];

	for (int i = 0; i < bunkers.size(); i++)
		delete bunkers[i];

	for (int i = 0; i < lasers.size(); i++)
		delete lasers[i];

	delete cannon;
	delete infoBar;

	for (int i = 0; i < NUM_TEXTURES; i++)
		delete textureArray[i];

	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
}

void Game::save() {

	string filename("partidaGuardada.txt");
	fstream out; 

	out.open(filename, std::ios_base::out); 
	if (!out.is_open()) {
		cerr << "Failed to open " << filename << '\n';
	}
	else

	//guardamos ca�on
	out << cannon->getInfo() << endl;

	//guardamos aliens
	for (int i = 0; i < aliens.size(); i++) {
		out << aliens[i]->getInfo() << endl;
	}

	//guardamos bunkers
	for (int i = 0; i < bunkers.size(); i++) {
		out << bunkers[i]->getInfo() << endl;
	}

	//guardaamos lasers
	for (int i = 0; i < lasers.size(); i++) {
		out << lasers[i]->getInfo() << endl;
	}

	//puntuacion
	out << "4 " << score << endl;

	out.close();
}

void Game::load()
{
	ifstream partida; partida.open("partidaGuardada.txt");			//aqui es donde se decide q mapa jugar
	if (!partida.is_open())
		throw string("fichero de partida no encontrado");

	//sabemos que son muchas variables, pero son solo ints y son para poder aclararnos mejor.
	int numObjeto, x, y, vidas, subt, scor, dir, vieneDeAlien; 	
	partida >> numObjeto;

	textureIndex = SPACESHIP;
	if (numObjeto == 0)
	{
		partida >> x >> y >> vidas;
		cannon = new Cannon(x, y, textureArray[textureIndex], this, vidas);
		partida >> numObjeto;
	}
	else throw string("datos de fichero no validos");

	textureIndex = ALIEN;
	while (numObjeto == 1)
	{
		partida >> x >> y >> subt;
		aliens.push_back(new Alien(x, y, subt, (x % 2 == 0), textureArray[textureIndex], this));
		partida >> numObjeto;
	}

	textureIndex = BUNKER;
	while (numObjeto == 2)
	{
		partida >> x >> y >>vidas;
		bunkers.push_back(new Bunker(x, y, vidas, textureArray[textureIndex]));
		partida >> numObjeto;
	}
	while (numObjeto == 3)
	{
		partida >> x >> y >> dir >> vieneDeAlien;
		lasers.push_back(new Laser(x, y, dir, (vieneDeAlien == 1), renderer));
		partida >> numObjeto;
	}
	
	if (numObjeto == 4)
	{
		partida >> scor;
		infoBar = new InfoBar(textureArray[4], textureArray[1], scor, cannon->getVidas());
	}
	else throw string("datos de fichero no validos");
}
