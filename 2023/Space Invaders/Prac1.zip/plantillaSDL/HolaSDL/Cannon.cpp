#include "Cannon.h"
#include "checkML.h"
#include "Game.h"
#include "InfoBar.h"
using namespace std;
using uint = unsigned int;

Cannon::Cannon() : pos(), text(), game() {}

Cannon::Cannon(int posx, int posy, Texture* tx, Game* g, int v) :
	pos(posx, posy), text(tx), game(g), vidas(v) {
	rectCannon.w = text->getFrameWidth();
	rectCannon.h = text->getFrameHeight();
}

void Cannon::Render()
{
	//rectCannon definido en .h
	rectCannon.x = pos.getX();
	rectCannon.y = pos.getY();
	

	//llama al render de texture.h
	text->renderFrame(rectCannon, 0, 0);
}

bool Cannon::Update()
{
	if ((direccion == -1 && pos.getX() > 0) ||												//si no te sales por la izquierda
		(direccion == 1 && pos.getX() < (game->GetWindowWidth() - text->getFrameWidth())))  //ni por la derecha
	{
		pos = pos + Vector2D((direccion * VELOCIDAD), 0);
	}
	
	return vidas > 0;
}

void Cannon::Hit() {
	game->UpdateVidas();
	vidas--;
}

void Cannon::TryToShoot()
{
	if (SDL_GetTicks() - lastTimeShoot > TIEMPORECARGA) //disparar cada x tiempo
	{
		game->fireLaser(pos, text->getFrameWidth()/2, -1 ,false); //el getframewidth es para q salga del centro y no de la esquina
		lastTimeShoot = SDL_GetTicks();
	}
}

void Cannon::handleEvent(SDL_Event event) {

	if (event.type == SDL_KEYDOWN) //si se ha pulsado una tecla
	{
		if (event.key.keysym.sym == SDLK_SPACE)
			TryToShoot();

		else if (direccion == 0) //para moverte en una direccion, tienes q estar no moviendote en la otra
		{
			if (event.key.keysym.sym == SDLK_RIGHT)
				direccion = 1;

			else
				direccion = -1;
		}
	}
	
	else if (event.type == SDL_KEYUP) //si se suelta una tecla, la direcci�n cambia a 0
	{
		direccion = 0; 
	}
}

SDL_Rect* Cannon::GetSDLRect()
{
	return &rectCannon;
}

string Cannon::getInfo() const
{
	string info;
	info = "0 "+ to_string(pos.getX())+ " " + to_string(pos.getY()) + " " + to_string(vidas);

	return info;
}



