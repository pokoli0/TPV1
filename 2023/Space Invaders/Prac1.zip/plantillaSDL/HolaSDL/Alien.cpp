#include "Alien.h"
#include "checkML.h"
#include "Game.h"

Alien::Alien() : pos(), subtipo(), text(), game() {}
Alien::Alien(int posx, int posy, int subt, bool post, Texture* t, Game* g) :
	pos(posx, posy), subtipo(subt), posture(post),text(t), game(g), starTime(SDL_GetTicks()), lastTimeShot(SDL_GetTicks()){
	rectAlien.w = text->getFrameWidth();			//se define la anchura/altura del sdlrect en la constructora
	rectAlien.h = text->getFrameHeight();
	tiempoRecarga = game->RandomGenerator(1500, 2000);
}

void Alien::Render()
{
	//rectAlien declarado en .h
	rectAlien.x = pos.getX();
	rectAlien.y = pos.getY();
	
	
	text->renderFrame(rectAlien, subtipo, (int) posture);
}
bool Alien::Update()
{
	int direction = game->getDirection();
	if (SDL_GetTicks() - starTime > frameRate) //para movernos solo cada frameRate
	{
		posture = !posture;					//cambiamos de postura en cada iteraccion
		starTime = SDL_GetTicks();
		pos = pos + Vector2D<>(direction * velocidad, 0);
		if ((direction < 0 && pos.getX() <= velocidad)						//si van hacia la izquierda y no cabrian en la siguiente iteracion
			|| (direction > 0 && pos.getX() > game->GetWindowWidth() - text->getFrameWidth()-velocidad)) //o hacia la derecha
			game->cannotMove();
	}
	if (subtipo == 0 && SDL_GetTicks() - lastTimeShot > tiempoRecarga) //si es disparador y ha pasado el tiempo de recarga
		TryShoot();														//se intenta disparar

	return !isDead;
}
void Alien::Hit() {
	isDead = true;
}

void Alien::TryShoot()
{
	game->fireLaser(pos, text->getFrameWidth() / 2, 1, true);
	tiempoRecarga = game->RandomGenerator(1500, 2000);

	lastTimeShot = SDL_GetTicks();
}

bool Alien::Lower(const int& MaximunHeight)
{
	pos = pos + Vector2D<>(0, velocidad);
	frameRate -= 40;
	if (pos.getY() > MaximunHeight)
		return true;
	else
		return false;
}

string Alien::getInfo() const
{
	string info;
	info = "1 " + to_string(pos.getX()) + " " + to_string(pos.getY()) + " " + to_string(subtipo);
	return info;
}

SDL_Rect* Alien::GetSDLRect()
{
	return &rectAlien;
}

int Alien::GetScore() const
{
	return scores[subtipo];
}
