#pragma once
#include "SceneObject.h"

class Ufo : public SceneObject
{
	enum states {hidden, visible, destroyed};
	states state = hidden;
	int waitTime, startTime;
	int velocidad = 10;

public:
	Ufo(Texture* texture, PlayState*, int x, int y); 
	Ufo(Texture* texture, PlayState*, ifstream& in);
	void Render() override;
	bool Hit(SDL_Rect* otherRect, char origin) override;
	void Save(ostream& out) const override;
	void Update() override;

private:
	void UfoDestroyed();
	void UfoHidden();
	void Drop();
	
};

