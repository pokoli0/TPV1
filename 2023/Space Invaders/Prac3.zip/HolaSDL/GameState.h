#pragma once
#include <SDL.h>
#include <list>
#include "EventHandler.h"
#include "gameList.h"
#include "texture.h"
#include <fstream>
using namespace std;

//declaraciones anticipadas
class Game;
class GameObject; 

class GameState
{
protected:
	GameList <GameObject, true>* objects;
	std::list <EventHandler*> eventHandlers;
	Game* game;
	GameState* prevState;
	Texture* fondo;

public: 
	GameState(Game* g, GameState* prevState);
	virtual ~GameState();
	virtual void update();
	virtual void render();
	virtual void handleEvent(const SDL_Event&);
	void addEventListener(EventHandler* listener);
	void addObjects(GameObject* object);
	virtual void save(ostream&) const {};
};

