#include "ShooterAlien.h"
#include "PlayState.h"



ShooterAlien::ShooterAlien(ifstream& Entrada, Texture* t, PlayState* g, MotherShip* m): 
	Alien(Entrada, t, g, m)
{
	Entrada >> tiempoRecarga;
	
}

void ShooterAlien::Update()
{
	Alien::Update();
	tiempoRecarga--;		//para poder pausar y q sea constante entre ordenadores
	if (tiempoRecarga <= 0)
		TryShoot();
}
void ShooterAlien::Save(ostream& out) const
{
	out << "2 " << pos.getX() << " " << pos.getY() << " " << subtipo << " " << tiempoRecarga << endl;
}
void ShooterAlien::TryShoot()
{
	tiempoRecarga = playState->RandomGenerator(100, 400);
	playState->fireLaser(pos.getX() + text->getFrameWidth() / 2, pos.getY(), 1, 'b');
}
