#include "GameStateMachine.h"
#include "PlayState.h"
#include "PauseState.h"
#include "MainMenuState.h"

GameStateMachine::GameStateMachine(Game* g, std::ifstream& in)
{
	pushState(new MainMenuState(g));
}

GameStateMachine::~GameStateMachine()
{
	while (!StateStack.empty())
		popState();
}

void GameStateMachine::pushState(GameState* newState)
{
	StateStack.push(newState);
}

void GameStateMachine::popState()
{
	delete StateStack.top(); //borrar memoria dinamica
	StateStack.pop();
}

void GameStateMachine::replaceState(GameState* newState)
{
	popState();
	pushState(newState);
}

void GameStateMachine::update()
{
	StateStack.top()->update();
}

void GameStateMachine::render() const
{
	StateStack.top()-> render();
}

void GameStateMachine::handleEvent(const SDL_Event& event)
{
	//cosas de gameStateMachine q por ahora no es nada
	StateStack.top()->handleEvent(event);
}

void GameStateMachine::save(ostream& out) const
{
	StateStack.top()->save(out);
}
