#pragma once
#include "GameState.h"
#include "Cannon.h"
#include "InfoBar.h"
#include "ShooterAlien.h"
#include "Bunker.h"
#include "Laser.h"
#include "Ufo.h"
#include "Bomb.h"
#include "Shield.h"
#include <random>
#include <queue>

class PlayState: public GameState
{
private:
	GameList<SceneObject, false>* sceneObjects;

	Cannon* cannon;
	MotherShip* motherShip;
	InfoBar* infobar;
	Shield* shield = NULL;

	int score = 0;
	int mapaActual = 0;
	mt19937_64 randomGenerator;

public:

	//implementados:
	PlayState(Game* g, const string& filename);
	~PlayState() override;
	void render() override;
	void update() override;
	void handleEvent(const SDL_Event&) override;
	void save(ostream&) const override;

	//getters
	int GetWindowHeight() const;
	int GetWindowWidth() const;
	SDL_Renderer* GetRenderer();

	//usados por los objetos
	void hasDied(GameList<GameObject, true>::anchor, GameList<SceneObject, false>::anchor);
	bool Attack(SDL_Rect* rect, char origin);
	void fireLaser(const int x, const int y, const int dir, const char fromAlien);
	void fireBomb(const int x, const int y);
	void fireReward(const int x, const int y);
	void addScore(const int scoreToAdd);
	int RandomGenerator(int min, int max);
	void UpdateVidas(const int);
	bool MayGrantReward(SDL_Rect* rect);
	

private:
	bool ReadObject(ifstream& in, bool readCannon);
	void AvanceMap();
};

