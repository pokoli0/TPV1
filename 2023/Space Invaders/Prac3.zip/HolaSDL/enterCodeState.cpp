#include "enterCodeState.h"
#include "Game.h"

enterCodeState::enterCodeState(Game* g, GameState* gs, bool s): GameState(g, gs), guardar(s)
{
	halfScreen = game->GetWindowWidth() / 2;
	fondo = game->GetTexture(Game::ENTERCODE);
	codigo = game->GetTexture(Game::CODIGO);
	nums = game->GetTexture(Game::NUMEROS);

	codigoRect.x = 310; codigoRect.y = 150;
	codigoRect.w = codigo->getFrameWidth(); codigoRect.h = codigo->getFrameHeight();

	numsRect.y = 220;						//la posicion en Y y la altura es constante, asiq podemos definirla aqui
	numsRect.h = nums->getFrameHeight(); numsRect.w = nums->getFrameWidth();
}

void enterCodeState::render()
{
	prevState->render();
	fondo->render();
	codigo->renderFrame(codigoRect, 0, 0);
	renderNums();

}

void enterCodeState::handleEvent(const SDL_Event& event)
{
	if (event.type == SDL_KEYDOWN)
	{
		if (event.key.keysym.sym == SDLK_ESCAPE)
			game->deleteState();

		else if (event.key.keysym.sym >= SDLK_0 && event.key.keysym.sym <= SDLK_9) //eso son los valores de las teclas numericas 0 y 9.
		{
			Code.push_back(event.key.keysym.sym - 48);
			codeSize++;
			numsRect.x = halfScreen - (codeSize * nums->getFrameWidth() + (codeSize - 1) * 5) / 2; //calculando donde van a estar
		}
		else if (event.key.keysym.sym == SDLK_BACKSPACE) //para borrar
		{
			Code.pop_back();
			codeSize--;
			numsRect.x = halfScreen - (codeSize * nums->getFrameWidth() + (codeSize - 1) * 5) / 2; //calculando donde van a estar
		}

		else if (event.key.keysym.sym == SDLK_RETURN)
		{
			if (codeSize > 0) //si se ha metido un codigo
			{
				string codestr;
				for (int i = 0; i < codeSize; i++)
				{
					codestr += to_string(Code[i]);
				}

				if (guardar)
					game->save(codestr);
				else
					game->load(codestr);
			}
			else
				game->deleteState();
		}
	}
}

void enterCodeState::renderNums()
{
	int x = numsRect.x; //guardas la posicion original
	for (int i = 0; i < codeSize; i++)
	{
		nums->renderFrame(numsRect, 0, Code[i]);
		numsRect.x += nums->getFrameWidth() + 5;
	}
	numsRect.x = x; //la recuperas
}

void enterCodeState::save(ostream& out) const
{
	prevState->save(out);
}
