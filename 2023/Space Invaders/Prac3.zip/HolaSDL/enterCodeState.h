#pragma once
#include "GameState.h"
#include <vector>
class enterCodeState : public GameState
{
	int halfScreen;
	Texture* codigo;
	Texture* nums;
	SDL_Rect codigoRect;
	SDL_Rect numsRect;
	bool guardar; //para saber si guardar o cargar
	int codeSize = 0;
	std::vector<int> Code;

public:
	enterCodeState(Game*, GameState*, bool);
	void render() override;
	void handleEvent(const SDL_Event&) override;
	void renderNums();
	void save(ostream&) const override;
};

