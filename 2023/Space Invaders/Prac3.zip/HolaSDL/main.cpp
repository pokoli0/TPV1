
#include "checkML.h"
#include <iostream>
#include "Game.h"
#include "InvadersError.h"

int main(int argc, char* argv[])
{

	try {
		Game* game = new Game();
		game->Run();
		delete game;
	}
	
	catch (const string Error) {
		cout << "exception: " << Error;
		SDL_Quit();
	}

	catch (InvadersError Error)
	{
		cout << Error.what();
	}

	return 0;
}
