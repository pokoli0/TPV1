#pragma once
#include "GameObject.h"
#include "texture.h"
#include "vector2D.h"

class InfoBar: public GameObject
{
private:
	Texture* textScore;
	Texture* textVidas;
	point2D posScore, posVidas;
	int vidas = 3;
	int score[4] = { 0, 0, 0, 0 };
	const int SCORE_SIZE = 4;
	SDL_Rect rectScore;
	SDL_Rect rectVidas;

public:
	InfoBar(GameState*, Texture* ts, Texture* tv, int s, int v);
	void Render() override;
	void Update() override;
	void Save(ostream& out) const override;
	void RenderVidas();
	void RenderScore();
	void UpdateScore(int scoreToAdd);
	void UpdateVidas(const int);
	void SetInfo(const int vid, int scor);
};

