#include "PlayState.h"
#include "Game.h"
#include "PauseState.h"
#include "EndState.h"
#include "Reward.h"
#include "InvadersError.h"


PlayState::PlayState(Game* g, const string& filename): GameState(g, nullptr), motherShip(new MotherShip(this)), randomGenerator(time(nullptr)), sceneObjects(new GameList<SceneObject, false>)
{
	GameState::addObjects(motherShip); //se crea la mothership para poder pasarsela a los aliens

	ifstream entradaMapa; entradaMapa.open(filename);
	while (ReadObject(entradaMapa, true));
	entradaMapa.close();

	infobar = new InfoBar(this, game->GetTexture(Game::NUMEROS), game->GetTexture(Game::SPACESHIP), score, cannon->getLives());
	objects->push_back(infobar);
	if (cannon == nullptr)
		throw fileFormatError(filename);
}

PlayState::~PlayState()
{
	delete sceneObjects;
	//la destructora de GameState se encarga de borrar objects
}

bool PlayState::ReadObject(ifstream& in, bool readCannon)
{
	int numObjecto; 
	in >> numObjecto;

	if (!in.fail()) {

		SceneObject* aux = nullptr;
		switch (numObjecto) {
		case 0:		//cannon
			if (readCannon)
				cannon = new Cannon(in, game->GetTexture(Game::SPACESHIP), game->GetTexture(Game::SHIELD_EFFECT), this);
			else
			{
				string s;
				getline(in, s); //para ignorar la entrada
			}
			
			GameState::addObjects(cannon);
			sceneObjects->push_back(cannon);
			GameState::addEventListener(cannon);
			break;

		case 1:		//alien
			motherShip->addAlien();
			aux = new Alien(in, game->GetTexture(Game::ALIEN), this, motherShip);
			GameState::addObjects(aux);
			sceneObjects->push_back(aux);
			break;

		case 2:		//shooter Alien
			motherShip->addAlien();
			aux = new ShooterAlien(in, game->GetTexture(Game::ALIEN), this, motherShip);
			GameState::addObjects(aux);
			sceneObjects->push_back(aux);
			break;

		case 3:		//mothership
			motherShip->SetMotherData(in);
			break;

		case 4:		//bunker
			aux = new Bunker(in, game->GetTexture(Game::BUNKER), this);
			GameState::addObjects(aux);
			sceneObjects->push_back(aux);
			break;

		case 5:		//UFO
			aux = new Ufo(game->GetTexture(Game::UFO), this, in);
			GameState::addObjects(aux);
			sceneObjects->push_back(aux);
			break;

		case 6:		//laser
			aux = new Laser(this, in);
			GameState::addObjects(aux);
			sceneObjects->push_back(aux);
			break;

		case 7:
			aux = new Bomb(this, game->GetTexture(Game::BOMB), in);
			GameState::addObjects(aux);
			sceneObjects->push_back(aux);
			break;

		case 8:		//score
			in >> score >> mapaActual;
			break;
		}
	}

	return !in.fail();
}

void PlayState::addScore(const int scoreToAdd)
{
	score += scoreToAdd;
	infobar->UpdateScore(score);
}

int PlayState::RandomGenerator(int min, int max)
{
	return uniform_int_distribution<int>(min, max)(randomGenerator);
}

void PlayState::UpdateVidas(const int v)
{
	infobar->UpdateVidas(v);
}

bool PlayState::MayGrantReward(SDL_Rect* rect)
{
	return cannon->GetReward(rect);
}

int PlayState::GetWindowHeight() const
{
	return game->GetWindowHeight();
}

int PlayState::GetWindowWidth() const
{
	return game->GetWindowWidth();
}

SDL_Renderer* PlayState::GetRenderer()
{
	return game->GetRenderer();
}

void PlayState::hasDied(GameList<GameObject, true>::anchor anchor, GameList<SceneObject, false>::anchor sceneAnchor)
{
	sceneObjects->erase(sceneAnchor);
	objects->erase(anchor);
}

bool PlayState::Attack(SDL_Rect* rect, char origin)
{
	bool hasHit = false;


	for (GameList<SceneObject, false>::forward_iterator it = sceneObjects->begin(); 
		!hasHit && it != sceneObjects->end(); it.operator++()) {
		hasHit = it.operator*().Hit(rect, origin);
	}

	return hasHit;
}

void PlayState::fireLaser(const int x, const int y, const int dir, const char fromAlien)
{
	Laser* auxLaser = new Laser(this, x, y, dir, fromAlien);
	objects->push_back(auxLaser);
	sceneObjects->push_back(auxLaser);
}

void PlayState::fireBomb(const int x, const int y)
{
	Bomb* auxBomb = new Bomb(this, game->GetTexture(Game::BOMB), x, y);
	objects->push_back(auxBomb);
	sceneObjects->push_back(auxBomb);
	
}

void PlayState::fireReward(const int x, const int y)
{
	Reward* auxRew = new Reward(this, [this]() {cannon->addShield();}, game->GetTexture(Game::SHIELD), x, y);
	objects->push_back(auxRew);
	sceneObjects->push_back(auxRew);
}

void PlayState::handleEvent(const SDL_Event& event)
{
	if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)
		game->addState(new PauseState(game, this));
		
	else
		GameState::handleEvent(event);
}

void PlayState::save(ostream& out) const
{
	for (GameList<GameObject, true>::forward_iterator it = objects->begin(); it != objects->end(); it.operator++()) {
		it.operator*().Save(out);
	}

	out << "8 " << score << " " << mapaActual;
}

void PlayState::render()
{
	game->GetTexture(Game::STARS)->render();
	GameState::render();
}

void PlayState::AvanceMap()
{
	if (mapaActual < (game->getNumMaps() - 1))
	{
		mapaActual++;

		cannon = new Cannon(this, game->GetTexture(Game::SPACESHIP), game->GetTexture(Game::SHIELD_EFFECT), cannon); //guardamos el ca��n

		//borramos los objetos (como son solo 3 q podriamos conservar, no me da pena)
		sceneObjects->clear();
		objects->clear();
		eventHandlers.clear(); 

		motherShip = new MotherShip(this);
		GameState::addObjects(motherShip);
		ifstream entradaMapa; entradaMapa.open(game->getMap(mapaActual));
		while (ReadObject(entradaMapa, false));
		entradaMapa.close();

		infobar = new InfoBar(this, game->GetTexture(Game::NUMEROS), game->GetTexture(Game::SPACESHIP), score, cannon->getLives());
		objects->push_back(infobar);
	}
	else
		game->changeState(new EndState(game, true));
}

void PlayState::update()
{
	GameState::update();

	if (cannon->getLives() <= 0 || motherShip->haveLanded())
		game->changeState(new EndState(game, false));
	else if (motherShip->getAlienCount() == 0)
		AvanceMap();
}