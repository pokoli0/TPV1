#include "Button.h"

Button::Button(GameState* g, Texture* t, Texture* th, int x, int y) : GameObject(g), pos(x - t->getFrameWidth()/2, y)
{
	text[0] = t;
	text[1] = th;
	rect.w = text[0]->getFrameWidth();
	rect.h = text[1]->getFrameHeight();
	rect.x = pos.getX();
	rect.y = pos.getY();
}

void Button::connect(Callback cb)
{
	buttonAction = cb;
}

void Button::handleEvent(const SDL_Event& event)
{
	if (hover && event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) //si est� sobre el bot�n y es click izquierdo
			buttonAction();
}

void Button::Render()
{
	text[(int)hover]->renderFrame(rect, 0, 0);
}

void Button::Update()
{
	SDL_Point point;
	SDL_GetMouseState(&point.x, &point.y);

	hover = SDL_PointInRect(&point, &rect); //true si est� sobre el rectangulo
}