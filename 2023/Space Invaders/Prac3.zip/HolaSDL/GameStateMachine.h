#pragma once
#include <stack>
#include "GameState.h"
#include <fstream>

class Game; 
class GameStateMachine
{
private: 
	std::stack <GameState*> StateStack;

public:
	GameStateMachine(Game* g, std::ifstream& in);
	~GameStateMachine();
	void pushState(GameState* newState);
	void popState();
	void replaceState(GameState*);
	void update();
	void render() const;
	void handleEvent(const SDL_Event&);
	void save(ostream&) const;
};

