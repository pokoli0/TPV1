#include "Ufo.h"
#include "PlayState.h"

using namespace std;


Ufo::Ufo(Texture* texture, PlayState* state, int x, int y)
	: SceneObject(state, x, y, texture), startTime (SDL_GetTicks()) {

	rect.w = text->getFrameWidth();
	rect.h = text->getFrameHeight();
	rect.y = pos.getY();
	waitTime = playState->RandomGenerator(2000, 5000);
}

Ufo::Ufo(Texture* texture, PlayState* stat, ifstream& in): SceneObject(stat, texture, in)
{
	rect.w = text->getFrameWidth();
	rect.h = text->getFrameHeight();
	rect.y = pos.getY();


	int st; in >> st;
	state = (states)st; //esto es un parse de int a state.

	in >> waitTime;
}


void Ufo::Render()
{
	if (state != hidden)
	{
		rect.x = pos.getX();
		text->renderFrame(rect, 0, (int)state - 1);
	}
	
}

bool Ufo::Hit(SDL_Rect* otherRect, char origin) {
	
	if (state == visible && origin == 'r' && SDL_HasIntersection(getRect(), otherRect))
	{
		playState->addScore(100); //no se si hay q hacer una constante para este 100
		UfoDestroyed();
		return true;
	}
	return false;
}

void Ufo::Save(ostream& out) const
{
	out << "5 " << pos.getX() << " " << pos.getY() << " " << (int)state << " " << waitTime <<endl;
}

void Ufo::Update()
{
	waitTime--;
	if (state == visible)			//si est� visible, se mueve
	{
		pos = pos - Vector2D(velocidad, 0);
		if (pos.getX() < 0)			//si se sale, se esconde
			UfoHidden();
	}
	else if (0 >= waitTime)	//si est� destruido o invisible, espera
	{
		if (state == hidden)
			state = visible;
		else
			UfoHidden();
	}
}

void Ufo::UfoDestroyed()
{
	state = destroyed;
	Drop();
	waitTime = 4; //tiempo de espera en el q es visible antes de destruirse
}

void Ufo::UfoHidden()
{
	state = hidden;
	pos = point2D(playState->GetWindowWidth(), pos.getY());
	waitTime = playState->RandomGenerator(100, 400);
}

void Ufo::Drop()
{
	/*int action = playState->RandomGenerator(0, 5);
	if (action == 1)
		playState->fireBomb(pos.getX() + text->getFrameWidth() / 2, pos.getY());
	else if (action == 2)*/
		playState->fireReward(pos.getX() + text->getFrameWidth() / 2, pos.getY());
}

