#pragma once
#include "Alien.h"
using uint = unsigned int;


class ShooterAlien : public Alien
{
private:
	uint tiempoRecarga;


	void TryShoot();
	

public:
	ShooterAlien(ifstream& Entrada, Texture* t, PlayState* g, MotherShip* m);
	void Update() override;
	void Save(ostream& out) const override;

};

