#pragma once
#include <fstream>
#include <SDL.h>
#include "GameState.h"
using namespace std;


class GameObject
{
protected: 
	GameState* State; 
	GameList<GameObject, true>::anchor Anchor;


public: 
	GameObject(GameState* g);
	void setListAnchor(GameList<GameObject, true>::anchor a);
	virtual void Render();
	virtual void Update();
	virtual void Save(ostream& in) const;
	virtual ~GameObject();
};

