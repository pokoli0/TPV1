/*Clase Game: contiene, al menos, el tama�o de la ventana, punteros a la ventana y al renderer, a los
elementos del juego (usa el tipo vector), el booleano exit, y el array de texturas (ver m�s abajo). Define
tambi�n las constantes que sean necesarias. Implementa m�todos p�blicos para inicializarse y destruirse,
el m�todo run con el bucle principal del juego, m�todos para dibujar el estado actual del juego (m�todo
render), actualizar (m�todo update), manejar eventos (m�todo handleEvents), obtener la direcci�n de
movimiento de los alien�genas (m�todo getDirection), informar de que no es posible moverse otra iteraci�n
m�s en la direcci�n actual (m�todo cannotMove) y disparar l�seres (m�todo fireLaser).
*/
#pragma once
#include "checkML.h"
#include <SDL.h>
#include <vector>
#include "texture.h"
#include <string>
#include <array> 
#include <random>
#include "InfoBar.h"
#include <list>
#include <queue>


using namespace std;

class SceneObject;
class Cannon;
class MotherShip;

class GameStateMachine;
class GameState;

class Game
{

public:
	//para q pueda usarse desde fuera
	enum textureName { STARS, MAINMENU,	TRANSPARENT, ENTERCODE,	PITCHBLACK,								   //fondos
					   SPACESHIP, BUNKER, ALIEN, UFO, SHIELD, SHIELD_EFFECT, BOMB,						   //objetos
					   NUMEROS, CARGAR_PARTIDA, CARGAR_PARTIDA_HOVER, CODIGO, CONTINUAR, CONTINUAR_HOVER, GAMEOVER, //TEXTOS (y sus hovers)
					   GUARDAR_PARTIDA, GUARDAR_PARTIDA_HOVER, HAS_GANADO, NUEVA_PARTIDA, NUEVA_PARTIDA_HOVER, 
					   SALIR, SALIR_HOVER, VOLVER_AL_MENU, VOLVER_AL_MENU_HOVER};


private:
	//constantes
	static const int NUM_TEXTURES = 28, NUM_MAPAS = 4, WINDOW_WIDTH = 800, WINDOW_HEIGHT = 600;
	const string partidasRoot = "../partidas/saved";
	const string MAPAS [NUM_MAPAS] = {"../mapas/urgente.txt", "../mapas/original.txt","../mapas/trinchera.txt","../mapas/lluvia.txt"};
	//const string MAPAS[NUM_MAPAS] = { "../mapas/urgente.txt"};

	//cosas de SDL
	SDL_Window* window = nullptr;
	SDL_Renderer* renderer = nullptr;

	GameStateMachine* stateMachine;
	bool exit = false;
	int mapaActual = 0;



#pragma region cosas de textura
	struct TextureInfo {
		const char* name;
		int framesVerticales;
		int framesHorizontales;
	};
	textureName textureIndex; //no, no hace falta. pero nos dice q lo usemos de todas maneras.

	TextureInfo textInfo[NUM_TEXTURES]{
		//fondos
		TextureInfo {"../images/fondos/stars.png", 1, 1},
		TextureInfo {"../images/fondos/mainMenu.png", 1, 1},
		TextureInfo {"../images/fondos/transparent.png", 1, 1},
		TextureInfo {"../images/fondos/enterCode.png", 1, 1},
		TextureInfo {"../images/fondos/pitchBlack.png", 1, 1},
		//objetos
		TextureInfo {"../images/spaceship.png", 1, 1},
		TextureInfo {"../images/bunker.png", 1, 4},
		TextureInfo {"../images/aliens.png", 3, 2},
		TextureInfo {"../images/ufo.png", 1, 2},
		TextureInfo {"../images/shield.png", 1, 1},
		TextureInfo {"../images/shield_effect.png", 1, 1},
		TextureInfo {"../images/bomb.png", 1, 1},
		//textos
		TextureInfo {"../images/textos/numbers.png", 1, 10},
		TextureInfo {"../images/textos/cargarPartida.png", 1, 1},
		TextureInfo {"../images/textos/cargarPartidaHover.png", 1, 1},
		TextureInfo {"../images/textos/codigo.png", 1, 1},
		TextureInfo {"../images/textos/continuar.png", 1, 1},
		TextureInfo {"../images/textos/continuarHover.png", 1, 1},
		TextureInfo {"../images/textos/gameOver.png", 1, 1},
		TextureInfo {"../images/textos/guardarPartida.png", 1, 1},
		TextureInfo {"../images/textos/guardarPartidaHover.png", 1, 1},
		TextureInfo {"../images/textos/hasGanado.png", 1, 1},
		TextureInfo {"../images/textos/nuevaPartida.png", 1, 1},
		TextureInfo {"../images/textos/nuevaPartidaHover.png", 1, 1},
		TextureInfo {"../images/textos/salir.png", 1, 1},
		TextureInfo {"../images/textos/salirHover.png", 1, 1},
		TextureInfo {"../images/textos/volverAlMenu.png", 1, 1},
		TextureInfo {"../images/textos/volverAlMenuHover.png", 1, 1},
	};

	Texture* textureArray[NUM_TEXTURES]; //array est�tico
#pragma endregion


public:
	Game();
	~Game();
	

	
	void quit();
	void Run();
	void Render();
	void handleEvents();
	void save(const string);
	void load(const string load);

	//getters
	int GetWindowWidth() const { return WINDOW_WIDTH; }
	int GetWindowHeight() const { return WINDOW_HEIGHT; }
	SDL_Renderer* GetRenderer() const { return renderer; }
	Texture* GetTexture(textureName indx) const { return textureArray[(int)indx]; }
	string getMap(const int n) const { return MAPAS[n]; }
	int getNumMaps() const { return NUM_MAPAS; }

	//stateChangers
	void changeState(GameState* gs);
	void addState(GameState* gs);
	void deleteState();
};

