#include "Laser.h"
#include "PlayState.h"
using namespace std;

bool Laser::Attack()
{
	return playState->Attack(&rect, color);
}

Laser::Laser(PlayState* g, int x, int y, int dir, char c) :
	SceneObject(g, x, y, nullptr), color(c), velocidad(0, 20*dir){

	renderer = playState->GetRenderer();
	rect.w = LASER_WIDTH;			//el tama�o no var�a, por lo que lo podemos definir en la constructora
	rect.h = LASER_HEIGHT;

}

Laser::Laser(PlayState* g, ifstream& in) : SceneObject(g, nullptr, in)
{
	renderer = playState->GetRenderer();
	rect.w = LASER_WIDTH;			//el tama�o no var�a, por lo que lo podemos definir en la constructora
	rect.h = LASER_HEIGHT;

	in >> color;
	if (color == 'r')
		velocidad = Vector2D(0, -20);
	else
		velocidad = Vector2D(0, 20);

}

void Laser::Render() {
	SceneObject::Render();
	//def: int SDL_SetRenderDrawColor(SDL_Renderer * renderer, Uint8 red, Uint8 green, Uint8 blue, Uint8 alpha);
	if (color == 'r')
		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); //green
		
	else
		SDL_SetRenderDrawColor(renderer, 0, 0, 255, 50); //red
		 
	

	SDL_RenderFillRect(renderer, &rect); //lo dibuja como un rect�ngulo
}

void Laser::Update() {
	//avanza de acuerdo a su velocidad
	pos = pos + velocidad;
	if (Attack())
	{
		playState->hasDied(Anchor, SceneAnchor);
	}	
		

	else if (pos.getY() < 0 || pos.getY() > playState->GetWindowHeight())
	{
		playState->hasDied(Anchor, SceneAnchor); //para q no se salga

	}
}

bool Laser::Hit(SDL_Rect* OtherRect, char origin)
{
	if (color != origin && SceneObject::Hit(OtherRect, origin))
	{
		playState->hasDied(Anchor, SceneAnchor);
		return true;
	}
	return false;
}

void Laser::Save(ostream& in) const 
{
	in << "6 " << pos.getX() << " " << pos.getY() << " " << color << endl;
}


