#pragma once
#include "GameState.h"



class PauseState : public GameState
{
private:
	int halfScreen;
	int unpause = false;
	


public:
	PauseState(Game*, GameState*);
	void render() override;
	void update() override;
	void handleEvent(const SDL_Event&) override;
	void save(ostream&) const override;

private:
	void addContinuar();
	void addGuardarPartida();
	void addCargarPartida();
	void addSalir();

};

