#pragma once;
#include "GameObject.h"
using uint = unsigned int;


class MotherShip : public GameObject
{
private: 
	uint frameRate = 1000, starTime;
	int direction = 1;
	bool shouldMove = true, canMove = true, hasLanded = false, lower = false;
	int alienNum = 0;

	//0=derecha, 1=cambiando, 2=izquierda
	int state = 2;

	int level= 0; //nivel de descenso, que afectar a la velocidad de los alien�genas

public: 
	MotherShip(GameState* g);
	void SetMotherData(ifstream& entrada);
	int getDirection() const;
	bool ShouldMove() const;
	void cannotMove();
	void aliendDied();
	void addAlien();
	void alienLanded();
	bool haveLanded() const;

	int getAlienCount() const;
	bool shouldLower() const;
	void Render() override;
	void Update() override;
	void Save(ostream& in) const override;
};
