#include "GameState.h"
#include "MotherShip.h"


MotherShip::MotherShip(GameState* game)
	:  GameObject(game), starTime(SDL_GetTicks()) { }

void MotherShip::SetMotherData(ifstream& entrada)
{
	entrada >> state >> level >> frameRate;

	if (state != 1)
		direction = state - 1;
}


int MotherShip::getDirection() const
{
	return direction;
}

bool MotherShip::ShouldMove() const
{
	return shouldMove;
}

void MotherShip::cannotMove()
{
	canMove = false;
}

void MotherShip::aliendDied()
{
	alienNum--;
}
void MotherShip::addAlien()
{
	alienNum++;
}
void MotherShip::alienLanded()
{
	hasLanded = true; 
}

bool MotherShip::haveLanded() const
{
	return hasLanded;
}


int MotherShip::getAlienCount() const
{
	return alienNum;
}

void MotherShip::Render()
{}

void MotherShip::Update()
{

	if (shouldMove) //solo pueden moverse un frame.
		shouldMove = false;

	else if (SDL_GetTicks() - starTime >= frameRate - 70*level)
	{
		shouldMove = true;
		starTime = SDL_GetTicks();

		if (!canMove)
		{
			
			canMove = true;
			level++;
			state = 1;
		}

		else if (state == 1)
		{
			direction = direction * (-1);
			state = 1 + direction; //para determinar si va a la izquierda o a la derecha
		}
			

	}




}

void MotherShip::Save(ostream & in) const
{
	in << "3 " << state << " " << level << " " << frameRate << endl;

}

bool MotherShip::shouldLower() const
{
	return state == 1;
}
