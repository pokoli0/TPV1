#include "Reward.h"
#include "PlayState.h"

Reward::Reward(PlayState* g, Callback cb, Texture* t, int x, int y) : SceneObject(g, x, y, t), effect(cb)
{
	rect.w = text->getFrameWidth();
	rect.h = text->getFrameHeight();
}

void Reward::Update()
{
	pos = pos + velocidad;
	if (grantReward())
	{
		effect();
		playState->hasDied(Anchor, SceneAnchor);
	}


	else if (pos.getY() < 0 || pos.getY() > playState->GetWindowHeight())
	{
		playState->hasDied(Anchor, SceneAnchor); //para q no se salga
	}

}

void Reward::Render()
{
	SceneObject::Render();
	text->renderFrame(rect, 0, 0);
}

void Reward::Connect(Callback cb)
{
	effect = cb;
}

bool Reward::grantReward()
{
	return playState->MayGrantReward(&rect);
}

bool Reward::Hit(SDL_Rect* OtherRect, char origin)
{
	return false;
}
