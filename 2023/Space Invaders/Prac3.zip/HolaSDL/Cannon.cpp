#include "Cannon.h"
#include "PlayState.h"
using namespace std;
using uint = unsigned int;


Cannon::Cannon(ifstream& in, Texture* tx, Texture* txS, PlayState* g) : SceneObject(g, tx, in), lastTimeShoot(SDL_GetTicks()), shield(txS) {
	rect.w = text->getFrameWidth();
	rect.h = text->getFrameHeight();
	
	shieldRect.w = shield->getFrameWidth();
	shieldRect.h = shield->getFrameHeight();
	

	in >> vidas >> TiempoRecarga;
}

void Cannon::Render()
{
	SceneObject::Render();
	text->renderFrame(rect, 0, 0);

	if (imunityTime > 0)
		RenderShiel();
}

Cannon::Cannon(PlayState* g, Texture* t, Texture* ts, Cannon* c) : 
	SceneObject(g, c->getX(), c->getY(), t), imunityTime(c->getShieldTime()), vidas(c->getLives()), shield(ts)
{
	shieldRect.w = shield->getFrameWidth();
	shieldRect.h = shield->getFrameHeight();

	rect.w = text->getFrameWidth();
	rect.h = text->getFrameHeight();
}

void Cannon::Update()
{
	if ((direccion == -1 && pos.getX() > 0) || (direccion == 1 && pos.getX() < (playState->GetWindowWidth() - text->getFrameWidth())))  //si no te sales
	{
		pos = pos + Vector2D((direccion * VELOCIDAD), 0);
	}
	
	if (imunityTime > 0)
	{
		imunityTime--;
	}
}

void Cannon::TryToShoot()
{
	if (SDL_GetTicks() - lastTimeShoot > TiempoRecarga) //disparar cada x tiempo
	{
		playState->fireLaser(pos.getX() + text->getFrameWidth()/2, pos.getY(), - 1, 'r'); //el getframewidth es para q salga del centro y no de la esquina
		lastTimeShoot = SDL_GetTicks();
	}
}

void Cannon::handleEvent(const SDL_Event& event) {

	if (event.type == SDL_KEYDOWN) //si se ha pulsado una tecla
	{
		if (event.key.keysym.sym == SDLK_SPACE)
			TryToShoot();

		else if (direccion == 0) //para moverte en una direccion, tienes q estar no moviendote en la otra
		{
			if (event.key.keysym.sym == SDLK_RIGHT)
				direccion = 1;

			else if (event.key.keysym.sym == SDLK_LEFT)
				direccion = -1;
		}
	}
	
	//si se suelta una tecla de direcci�n, la direcci�n cambia a 0
	else if (event.type == SDL_KEYUP && (event.key.keysym.sym == SDLK_LEFT || event.key.keysym.sym == SDLK_RIGHT))
	{
		direccion = 0; 
	}
}


bool Cannon::Hit(SDL_Rect* OtherRect, char origin)
{	
	if (origin == 'b' && SceneObject::Hit(OtherRect, origin))
	{
		if (imunityTime <= 0)
		{
			vidas--;
			playState->UpdateVidas(vidas);
		}
		
		return true;
	} 
	return false;
}

void Cannon::Save(ostream& out) const
{
	out << "0 " << pos.getX() << " " << pos.getY() << " " << vidas << " " << TiempoRecarga << endl;
}

void Cannon::setVidas(const int v)
{
	vidas = v;
}

bool Cannon::GetReward(SDL_Rect* otherRect)
{
	return SceneObject::Hit(otherRect, ' ');
}

void Cannon::addShield()
{
	imunityTime = 500;
}

void Cannon::RenderShiel()
{
	shieldRect.x = pos.getX() - 4;
	shieldRect.y = pos.getY() - 4;

	shield->render(shieldRect);
}

int Cannon::getShieldTime()
{
	return imunityTime;
}

