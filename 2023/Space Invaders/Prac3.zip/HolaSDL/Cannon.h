/*Clase Cannon : al igual que los anteriores, sus atributos incluyen su posici�n actual, un puntero a su textura y
un puntero al juego(que utilizar� para lanzar l�seres).Adem�s, mantiene la direcci�n actual del movimiento,
el n�mero de vidas que le quedan y el tiempo restante de recarga del l�ser.Implementa tambi�n m�todos
para construirse, dibujarse(render), actualizarse, es decir, moverse(m�todo update), recibir da�o(m�todo
hit) y manejar eventos del teclado(m�todo handleEvent), que determinan el estado de movimiento y
permiten lanzar el l�ser(barra espaciadora).*/

#pragma once
#include "SceneObject.h"
#include "EventHandler.h"
#include <string>
using uint = unsigned int;
using namespace std;

//class Game;

class Cannon : public SceneObject, public EventHandler
{
private:
	int direccion = 0;
	int vidas = 3;
	int TiempoRecarga = 700;
	uint lastTimeShoot;
	int imunityTime = 0;
	Texture* shield;
	SDL_Rect shieldRect;

	const int VELOCIDAD = 20;

public:
	Cannon(ifstream& in, Texture* tx, Texture* txS, PlayState* g);
	Cannon(PlayState* g, Texture* t, Texture* ts, Cannon* c);
	void handleEvent(const SDL_Event& event) override;
	
	int getLives() const { return vidas; }
	int getX() const { return pos.getX(); };
	int getY() const { return pos.getY(); };
	int getShieldTime();
	void Update() override;
	void Render() override;
	bool Hit(SDL_Rect* OtherRect, char origin) override;
	bool GetReward(SDL_Rect* OtherRect);
	void Save(ostream& out) const  override;
	void setVidas(const int);
	void addShield();

private: //metodos privados
	void TryToShoot();
	void RenderShiel();
};

