#include "MainMenuState.h"
#include "Button.h"
#include "Game.h"
#include "PlayState.h"
#include "enterCodeState.h"

MainMenuState::MainMenuState(Game* g): GameState(g, nullptr)
{
	halfScreen = game->GetWindowWidth() / 2;
	fondo = game->GetTexture(Game::MAINMENU);

	addPartidaNueva();
	addCargarPartida();
	addSalir();

}

void MainMenuState::addPartidaNueva()
{
	Button* aux = new Button(this, game->GetTexture(Game::NUEVA_PARTIDA), game->GetTexture(Game::NUEVA_PARTIDA_HOVER), halfScreen, 130);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {shouldchange = true;});
}

void MainMenuState::addCargarPartida()
{
	Button* aux = new Button(this, game->GetTexture(Game::CARGAR_PARTIDA), game->GetTexture(Game::CARGAR_PARTIDA_HOVER), halfScreen, 180);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {game->addState(new enterCodeState(game, this, false));});
}

void MainMenuState::addSalir()
{
	Button* aux = new Button(this, game->GetTexture(Game::SALIR), game->GetTexture(Game::SALIR_HOVER), halfScreen, 230);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {game->quit();});
}

void MainMenuState::render()
{
	fondo->render();
	GameState::render();
}

void MainMenuState::update()
{
	GameState::update();
}

void MainMenuState::handleEvent(const SDL_Event& event)
{
	if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)
		game->quit();
	else
		GameState::handleEvent(event);

	if (shouldchange)
		game->changeState(new PlayState(game, game->getMap(0)));
}
