#include "PauseState.h"
#include "Game.h"
#include "Button.h"
#include "enterCodeState.h"

PauseState::PauseState(Game* g, GameState* prevGS) : GameState(g, prevGS)
{
	halfScreen = game->GetWindowWidth() / 2;
	fondo = game->GetTexture(Game::TRANSPARENT);

	addContinuar();
	addGuardarPartida();
	addCargarPartida();
	addSalir();
}

void PauseState::render()
{
	prevState->render();
	fondo->render();
	GameState::render();
}

void PauseState::update()
{
	GameState::update();
}

void PauseState::handleEvent(const SDL_Event& event)
{
	GameState::handleEvent(event);

	if (unpause)
		game->deleteState();
}

void PauseState::save(ostream& out) const
{
	prevState->save(out);
}

void PauseState::addContinuar()
{
	Button* aux = new Button(this, game->GetTexture(Game::CONTINUAR), game->GetTexture(Game::CONTINUAR_HOVER), halfScreen, 100);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {unpause = true;});
}

void PauseState::addGuardarPartida()
{
	Button* aux = new Button(this, game->GetTexture(Game::GUARDAR_PARTIDA), game->GetTexture(Game::GUARDAR_PARTIDA_HOVER), halfScreen, 200);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {game->addState(new enterCodeState(game, this, true));});
}

void PauseState::addCargarPartida()
{
	Button* aux = new Button(this, game->GetTexture(Game::CARGAR_PARTIDA), game->GetTexture(Game::CARGAR_PARTIDA_HOVER), halfScreen, 300);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {game->addState(new enterCodeState(game, this, false));});
}

void PauseState::addSalir()
{
	Button* aux = new Button(this, game->GetTexture(Game::SALIR), game->GetTexture(Game::SALIR_HOVER), halfScreen, 400);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {game->quit();});
}
