#pragma once
#include "GameState.h"
class MainMenuState : public GameState
{
private:
	int halfScreen;
	bool shouldchange = false;


public:
	MainMenuState(Game*);
	void render() override;
	void update() override;
	void handleEvent(const SDL_Event&) override;

private:
	void addPartidaNueva();
	void addCargarPartida();
	void addSalir();
};

