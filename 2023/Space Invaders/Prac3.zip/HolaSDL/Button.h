#pragma once
#include "GameObject.h"
#include "vector2D.h"
#include "EventHandler.h"
#include <functional>
#include "texture.h"

class Button : public GameObject, public EventHandler
{
	using Callback = std::function<void(void)>;
private:
	Callback buttonAction;
	SDL_Rect rect;
	Texture* text[2];
	point2D pos;
	bool hover = false; //para el hover

public: 
	Button(GameState*, Texture*, Texture*, int x, int y);
	void connect(Callback);
	void handleEvent(const SDL_Event&) override;
	void Render() override;
	void Update() override;
	void Save();

};

