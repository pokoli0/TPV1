#include "GameState.h"
#include "GameObject.h"

//vale poli guapa te digo
//aqui hay mucha abstracci�n. la mayoria de metodos simplemente recorren bucles llamando a los metodos de esos objetos
//o a�aden/ borran objetos de metodos espec�ficos.
//poco mas tbh

GameState::GameState(Game* g, GameState* prevSt) : game(g), prevState(prevSt), objects(new GameList<GameObject, true>), eventHandlers() {}

GameState::~GameState()
{
	delete objects;
}

void GameState::update()
{
	for (GameList<GameObject, true>::forward_iterator it = objects->begin(); it != objects->end(); it.operator++()) {
		it.operator*().Update();
	}
}

void GameState::render()
{
	//porq motivo tenemos q usar el .operator++() en lugar de poner ++ directamente? lo desconozco
	for (GameList<GameObject, true>::forward_iterator it = objects->begin(); it != objects->end(); it.operator++()) {
		it.operator*().Render();
	}
}

void GameState::handleEvent(const SDL_Event& event)
{
	for (list<EventHandler*>::iterator it = eventHandlers.begin(); it != eventHandlers.end(); it++) {
		(*it)->handleEvent(event);
	}
}

void GameState::addEventListener(EventHandler* listener)
{
	eventHandlers.push_back(listener);
}

void GameState::addObjects(GameObject* object)
{
	objects->push_back(object);
}

