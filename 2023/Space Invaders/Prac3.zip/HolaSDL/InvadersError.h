#pragma once
#include <stdexcept>
#include <SDL.h>
#include <string>
class InvadersError: public std::logic_error
{
public:
	InvadersError(std::string& s): logic_error(s){}
};

class SDLError : public InvadersError
{
public:
	SDLError() : InvadersError(std::to_string(*SDL_GetError())) {}
};

class fileFormatError : public InvadersError
{
public:
	fileFormatError(const std::string& name): InvadersError("El archivo con nombre \"" + name + "\" contiene datos inv�lidos") {}
};