
#include "Game.h"
#include <SDL_image.h>
#include "PlayState.h"
#include <ctime>
#include <fstream>
#include "GameStateMachine.h"
#include "InvadersError.h"




//constructora. Carga las texturas, crea la ventana y el renderer
Game::Game() {

	//las cosas de SDL
	SDL_Init(SDL_INIT_EVERYTHING);
	window = SDL_CreateWindow("SPACE INVADERS", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	if (window == nullptr || renderer == nullptr)  //si no encuentra:
		throw SDLError();

	
	//cargar texturas
	try {
		for (int i = 0; i < NUM_TEXTURES; i++) {
			textureArray[i] = new Texture(renderer, textInfo[i].name,			//renderer, nombre
				textInfo[i].framesVerticales, textInfo[i].framesHorizontales);  //numero de frames
		}
	} catch (string e) { throw string("archivo de textura no encontrado o no v�lido"); }
	catch (exception e) { throw string("problema al cargar la textura"); }

	ifstream entradaMapa; entradaMapa.open(MAPAS[0]);
	stateMachine = new GameStateMachine(this, entradaMapa);
	entradaMapa.close();
}

void Game::Render() {

	SDL_RenderClear(renderer);
	stateMachine->render();

	//mostrarlo
	SDL_RenderPresent(renderer);
}

void Game::Run() { 


	while (!exit)
	{
		Render();
		stateMachine->update();
		handleEvents();

		SDL_Delay(40);
	}
}


//si el evento es alguno de los que nos interesan, se lo pasa a cannon o lo ejecuta
void Game::handleEvents()
{
	SDL_Event event;
	while (SDL_PollEvent(&event) && !exit) {
		stateMachine->handleEvent(event);
	}
}




//cambia exit a false para que se acabe el bucle de juego
void Game::quit() {

	exit = true;
}

//destructora
Game::~Game()
{
	delete stateMachine;

	for (int i = 0; i < NUM_TEXTURES; i++)
		delete textureArray[i];

	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
}

void Game::save(const string code) 
{
	fstream out; 

	string filename = partidasRoot + code + ".txt";
	out.open(filename, std::ios_base::out); 
	if (!out.is_open()) {
		throw string("uh ho, problemas abriendo el archivo");
	}
	else
	{
		stateMachine->save(out);
		deleteState();
		out.close();
	}
}


void Game::load(const string code)
{
	fstream in;

	string filename = partidasRoot + code + ".txt";
	in.open(filename);
	if (!in.is_open()) {
		SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "ECHA EL FRENO MADALENO", "parece que no existe esa partida", window); //la ventana de error
		deleteState();
	}
	else
	{
		in.close();
		deleteState();
		changeState(new PlayState(this, filename));
	}

}

void Game::changeState(GameState* gs)
{
	stateMachine->replaceState(gs);
}

void Game::addState(GameState* gs)
{
	stateMachine->pushState(gs);
}

void Game::deleteState()
{
	stateMachine->popState();
}
