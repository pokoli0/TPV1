#pragma once
#include "SceneObject.h"
#include <functional>
using Callback = std::function<void(void)>;
class Reward : public SceneObject
{
private:
	Callback effect;
	Vector2D<> velocidad = Vector2D(0, 20);

public:
	Reward(PlayState*, Callback, Texture*, int x, int y);
	void Update() override;
	void Render() override;
	void Connect(Callback);
	bool grantReward();
	bool Hit(SDL_Rect* OtherRect, char origin) override;
};

