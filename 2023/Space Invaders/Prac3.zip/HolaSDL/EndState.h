#pragma once
#include "GameState.h"
class EndState : public GameState
{
private:

	Texture* Header;
	SDL_Rect headerRect;
	int halfscreen;
	bool goBack = false;
	

public:
	EndState(Game*, bool);
	void render() override;
	void update() override;
	void handleEvent(const SDL_Event&) override;

private:
	void addVolver();
	void addSalir();
};

