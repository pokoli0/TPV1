#pragma once
#include "SceneObject.h"
class Bomb : public SceneObject
{
private:
	Vector2D<> velocidad;
	int vidas = 2;
	bool Attack();

public:
	Bomb(PlayState* g, Texture* t, int x, int y);
	Bomb(PlayState* g, Texture* t, ifstream& in);

	void Render() override;
	void Update() override;
	bool Hit(SDL_Rect* OtherRect, char origin) override;


	void Save(ostream& in) const override;
};

