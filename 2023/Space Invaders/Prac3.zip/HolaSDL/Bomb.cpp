#include "Bomb.h"
#include "PlayState.h"

bool Bomb::Attack()
{
	return playState->Attack(&rect, 'b'); //blue porq no hace da�o a los aliens
}

Bomb::Bomb(PlayState* g, Texture* t, int x, int y): SceneObject(g, x, y, t), velocidad(0, 15) {

	rect.w = text->getFrameWidth();
	rect.h = text->getFrameHeight();
}

Bomb::Bomb(PlayState* g, Texture* t, ifstream& in): SceneObject(g, t, in), velocidad(0, 15)
{
	in >> vidas;
	rect.w = text->getFrameWidth();
	rect.h = text->getFrameHeight();
}

void Bomb::Render()
{
	SceneObject::Render();
	text->renderFrame(rect, 0, 0);
}

void Bomb::Update()
{
	
	if (Attack())
	{
		vidas--;
		if (vidas == 0)
		{
			playState->hasDied(Anchor, SceneAnchor);
		}
	}


	else if (pos.getY() < 0 || pos.getY() > playState->GetWindowHeight())
	{
		playState->hasDied(Anchor, SceneAnchor); //para q no se salga

	}
	else
		pos = pos + velocidad; //se cambia el orden de ataque y movimiento porque si le da a algo, no se mueve
}

bool Bomb::Hit(SDL_Rect* OtherRect, char origin)
{
	if (origin == 'r' && SceneObject::Hit(OtherRect, origin))
	{
		vidas--;
		if (vidas == 0)
			playState->hasDied(Anchor, SceneAnchor);

		return true;
	}
	return false;
}

void Bomb::Save(ostream& in) const
{
	in << "7 " << pos.getX() << " " << pos.getY() << " " << vidas << endl;
}
