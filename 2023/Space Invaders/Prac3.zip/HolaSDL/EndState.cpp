#include "EndState.h"
#include "Game.h"
#include "Button.h"
#include "MainMenuState.h"

EndState::EndState(Game* g, bool hasWon) : GameState(g, nullptr) 
{
	fondo = game->GetTexture(Game::PITCHBLACK);
	halfscreen = game->GetWindowWidth() / 2;
	if (hasWon)
	{
		Header = game->GetTexture(Game::HAS_GANADO);
	}
	else
		Header = game->GetTexture(Game::GAMEOVER);

	headerRect.x = halfscreen - Header->getFrameWidth(); headerRect.y = 150;		//situamos el texto de gameover/has ganado
	headerRect.w = Header->getFrameWidth() * 2; headerRect.h = Header->getFrameHeight() * 2;

	addVolver();
	addSalir();

}

void EndState::render()
{
	fondo->render();
	Header->renderFrame(headerRect, 0, 0);

	GameState::render();
}

void EndState::update()
{
	GameState::update();
}

void EndState::handleEvent(const SDL_Event& event)
{
	GameState::handleEvent(event);
	if (goBack)
		game->changeState(new MainMenuState(game));
}

void EndState::addVolver()
{
	Button* aux = new Button(this, game->GetTexture(Game::VOLVER_AL_MENU), game->GetTexture(Game::VOLVER_AL_MENU_HOVER), halfscreen, 300);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {goBack = true;});
}

void EndState::addSalir()
{
	Button* aux = new Button(this, game->GetTexture(Game::SALIR), game->GetTexture(Game::SALIR_HOVER), halfscreen, 400);
	objects->push_back(aux);
	eventHandlers.push_back(aux);
	aux->connect([this]() {game->quit();});
}
