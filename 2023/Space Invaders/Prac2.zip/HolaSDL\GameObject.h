#pragma once
#include <fstream>
#include <SDL.h>
#include "Game.h"
using namespace std;


//class Game;

class GameObject
{
protected: 
	Game* game; 


public: 
	GameObject(Game* g);
	virtual void Render();
	virtual void Update();
	virtual void Save(ostream& in) const;
	virtual ~GameObject();
};

