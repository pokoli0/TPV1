
#include "checkML.h"
#include <iostream>
#include "Game.h"

int main(int argc, char* argv[])
{

	try {
		Game* game = new Game();
		game->Run();
		delete game;
	}
	
	catch (const string Error) {
		cout << "exception: " << Error;
		SDL_Quit();
		
	}

	return 0;
}
