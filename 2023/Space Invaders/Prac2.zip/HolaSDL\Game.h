/*Clase Game: contiene, al menos, el tama�o de la ventana, punteros a la ventana y al renderer, a los
elementos del juego (usa el tipo vector), el booleano exit, y el array de texturas (ver m�s abajo). Define
tambi�n las constantes que sean necesarias. Implementa m�todos p�blicos para inicializarse y destruirse,
el m�todo run con el bucle principal del juego, m�todos para dibujar el estado actual del juego (m�todo
render), actualizar (m�todo update), manejar eventos (m�todo handleEvents), obtener la direcci�n de
movimiento de los alien�genas (m�todo getDirection), informar de que no es posible moverse otra iteraci�n
m�s en la direcci�n actual (m�todo cannotMove) y disparar l�seres (m�todo fireLaser).
*/
#pragma once
#include "checkML.h"
#include <SDL.h>
#include <vector>
#include "texture.h"
//#include "SceneObject.h"
#include <string>
#include <array> 
#include <random>
#include "InfoBar.h"
#include <list>
#include <queue>

using namespace std;

class SceneObject;
class Cannon;
class MotherShip;


class Game
{
private:
	//constantes
	static const int NUM_TEXTURES = 6, WINDOW_WIDTH = 800, WINDOW_HEIGHT = 600;
	//const char* textRoot = "../images/"; //nos da error y no funciona. No es estrictamente necesaria asiq preferimos no usarla
	const string MAPAS [3] = {"../mapas/original.txt","../mapas/trinchera.txt","../mapas/lluvia.txt"};
	const int MAXIMUN_ALIEN_HEIGHT = 450; //altura m�xima a la q pueden llegar los aliens. al llegar a ella, pierdes

	//cosas de SDL
	SDL_Window* window = nullptr;
	SDL_Renderer* renderer = nullptr;
	mt19937_64 randomGenerator;
	
	std::list <SceneObject*> Objects;
	Cannon* cannon;
	MotherShip* motherShip;



	InfoBar* infoBar;

	bool exit = false;
	int score = 0;
	queue <list<SceneObject*>::iterator> deadObjects;
#pragma region cosas de textura
	struct TextureInfo {
		const char* name;
		int framesVerticales;
		int framesHorizontales;
	};
	enum textureName { STARS, SPACESHIP, BUNKER, ALIEN, NUMBERS, UFO};
	textureName textureIndex; //no, no hace falta. pero nos dice q lo usemos de todas maneras.

	TextureInfo textInfo[NUM_TEXTURES]{
		TextureInfo {"../images/stars.png", 1, 1},
		TextureInfo {"../images/spaceship.png", 1, 1},
		TextureInfo {"../images/bunker.png", 1, 4},
		TextureInfo {"../images/aliens.png", 3, 2},
		TextureInfo {"../images/numbers.png", 1, 10},
		TextureInfo {"../images/ufo.png", 1, 2}
	};

	Texture* textureArray[NUM_TEXTURES]; //array est�tico
#pragma endregion


public:
	Game();
	~Game();
	void quit();
	void Run();
	void UpdateVidas();
	void hasDied(list<SceneObject*>::iterator iterator);
	bool Attack(SDL_Rect* rect, char origin);
	void addScore(const int scoreToAdd);

	int GetWindowWidth() const {return WINDOW_WIDTH;} int GetWindowHeight() const { return WINDOW_HEIGHT; }
	void fireLaser(const int x, const int y, const int dir, const char fromAlien);
	int RandomGenerator(int min, int max);
	

private: //metodos privados
	void Render();
	void Update();
	void handleEvents();


	void readMap(const string filename);
	void save(const string);
	void AsignIterator();
	void DeleteDEadObjects();
	void load(const string filename);
};

